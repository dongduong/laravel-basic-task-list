<?php

return [
    'site_title' => 'MyHotelManagement',
];
