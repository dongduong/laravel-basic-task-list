<?php

return [
    'site_title' => 'MyLearningMS',
];
